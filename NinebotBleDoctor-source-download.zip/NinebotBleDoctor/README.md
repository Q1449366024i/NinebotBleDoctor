# 九号 BLE 检测与诊断工具（Android）

版本：1.0.0（源码首版）

## 当前实现
- BLE 扫描（12 秒自动停止），展示设备名称、地址和 RSSI。
- 连接用户选择的 BLE 设备，并发现 GATT 服务与特征。
- 显示特征 UUID 与 Read / Write / Notify / Indicate 等属性。
- 只对声明 Read 的特征发起读取。
- 对支持 Notify / Indicate 且具有标准 CCCD 的特征订阅通知。
- 记录读回值、通知和连接事件，导出 TXT 报告。
- 不包含任意特征写入、命令重放、校准或车辆参数修改功能。

## 尚未验证
- 尚未在真实九号 MZ MIX 2024 上实测连接兼容性。
- 不保证车辆所有服务/特征都可访问；部分可能需要配对、授权或应用层握手。
- 不解码九号专有协议，不推断电量、速度、故障码或氛围灯命令。
- Android 各厂商的 BLE 权限、后台限制及错误报告导出流程可能不同。
- 此项目没有在本次交付环境中完成 Android 编译或实机测试。

## 如何获得 APK（GitHub Actions 自动构建）

本项目已包含 `.github/workflows/build-apk.yml`。由于当前工作环境没有 Android SDK/Gradle，且无法连接外部下载源，不能在这里直接编译 APK。可以用 GitHub 的免费 Actions 云端构建：

1. 在 GitHub 创建一个空仓库，例如 `NinebotBleDoctor`。
2. 把本 ZIP 解压后的**项目文件和 `.github` 隐藏文件夹**上传到仓库根目录（不要只上传 ZIP 文件）。
3. 打开仓库的 **Actions** 页面；如果提示，先启用 Actions。
4. 在左侧选择 **Build Ninebot BLE Doctor APK**，点击 **Run workflow**。
5. 等待任务变成绿色成功状态，打开该次运行页面底部的 **Artifacts**。
6. 下载 `NinebotBleDoctor-debug-apk`，解压后得到 `app-debug.apk`，传到安卓手机安装。

首次安装非商店 APK 时，Android 可能要求允许当前文件管理器或浏览器“安装未知应用”。只对你自己构建并信任的 APK 开启此权限。

## 本地构建（如果电脑已安装 Android Studio）

- 安装 Android SDK Platform 35 和 JDK 17。
- 用 Android Studio 打开项目根目录并完成 Gradle Sync。
- 运行 `gradle assembleDebug`，或使用 Android Studio 的 Build > Build APK(s)。
- APK 通常输出到 `app/build/outputs/apk/debug/app-debug.apk`。

## 使用方式
1. 安装并打开 APK，允许附近设备权限。
2. 手机开启蓝牙；Android 11 及更早版本扫描可能还需要定位权限及开启系统定位。
3. 点击“开始扫描”，选择设备，点击“连接所选设备并发现服务”。
4. 选择带 Read 属性的特征读取，或对 Notify/Indicate 特征订阅通知。
5. 使用“导出日志”保存诊断文本。

默认只读：订阅通知时，Android BLE 协议会写入标准 CCCD 订阅描述符；除此以外，应用不提供任意特征写入入口。请仅在车辆静止时操作。
