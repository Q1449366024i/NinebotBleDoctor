package com.example.ninebotbledoc;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 100;
    private static final int CREATE_EXPORT = 101;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private boolean scanning = false;
    private final Map<String, ScanResult> devices = new LinkedHashMap<>();
    private final List<String> deviceRows = new ArrayList<>();
    private final List<BluetoothGattCharacteristic> characteristics = new ArrayList<>();
    private final List<String> characteristicRows = new ArrayList<>();
    private final StringBuilder log = new StringBuilder();
    private ArrayAdapter<String> deviceAdapter;
    private ArrayAdapter<String> characteristicAdapter;
    private ListView deviceList;
    private ListView characteristicList;
    private TextView status;
    private TextView selectedInfo;
    private int selectedDeviceIndex = -1;
    private int selectedCharacteristicIndex = -1;
    private BluetoothDevice connectedDevice;
    private boolean pendingNotify = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        buildUi();
        appendLog("应用启动。默认只读；不会发送任意车辆控制指令。");
        if (adapter == null) setStatus("此设备不支持蓝牙。", true);
        else requestPermissionsIfNeeded();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(8));
        root.setBackgroundColor(0xFFF4F6FA);

        TextView title = new TextView(this);
        title.setText("九号 BLE 检测与诊断");
        title.setTextSize(23); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(0xFF172033);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("扫描 · GATT 服务 · 只读特征 · 通知日志");
        subtitle.setTextSize(13); subtitle.setTextColor(0xFF586174);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2); subLp.topMargin = dp(4);
        root.addView(subtitle, subLp);

        status = new TextView(this); status.setText("准备就绪"); status.setTextSize(13); status.setTextColor(0xFF2457C5);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2); statusLp.topMargin = dp(10); statusLp.bottomMargin = dp(6);
        root.addView(status, statusLp);

        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        addButton(buttons, "开始扫描", v -> startScan(), 1);
        addButton(buttons, "停止扫描", v -> stopScan(), 1);
        addButton(buttons, "断开连接", v -> disconnect(), 1);
        root.addView(buttons, new LinearLayout.LayoutParams(-1, -2));

        TextView deviceHeader = sectionTitle("附近 BLE 设备（点选后连接）"); root.addView(deviceHeader);
        deviceList = new ListView(this); deviceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, deviceRows); deviceList.setAdapter(deviceAdapter);
        deviceList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        root.addView(deviceList, new LinearLayout.LayoutParams(-1, 0, 2.0f));
        deviceList.setOnItemClickListener((parent, view, position, id) -> {
            selectedDeviceIndex = position; deviceList.setItemChecked(position, true);
            ScanResult result = devices.get(deviceRows.get(position).split("\\n")[0]);
            if (result != null) { connectedDevice = result.getDevice(); setStatus("已选择设备：" + safeName(connectedDevice), false); appendLog("选择设备：" + deviceRows.get(position).replace('\n', ' ')); }
        });
        Button connect = new Button(this); connect.setText("连接所选设备并发现服务"); connect.setOnClickListener(v -> connectSelected());
        root.addView(connect, new LinearLayout.LayoutParams(-1, -2));

        root.addView(sectionTitle("GATT 特征（选中后可读取或订阅通知）"));
        characteristicList = new ListView(this); characteristicAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, characteristicRows); characteristicList.setAdapter(characteristicAdapter);
        root.addView(characteristicList, new LinearLayout.LayoutParams(-1, 0, 2.2f));
        characteristicList.setOnItemClickListener((parent, view, position, id) -> { selectedCharacteristicIndex = position; characteristicList.setItemChecked(position, true); showSelectedCharacteristic(); });

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        addButton(actions, "读取特征", v -> readSelected(), 1);
        addButton(actions, "订阅通知", v -> enableNotify(), 1);
        addButton(actions, "导出日志", v -> exportLog(), 1);
        root.addView(actions, new LinearLayout.LayoutParams(-1, -2));

        selectedInfo = new TextView(this); selectedInfo.setText("尚未选择特征"); selectedInfo.setTextColor(0xFF586174); selectedInfo.setTextSize(12);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1, -2); infoLp.topMargin = dp(4); root.addView(selectedInfo, infoLp);

        TextView disclaimer = new TextView(this);
        disclaimer.setText("安全说明：不包含任意写入功能。订阅通知会向 BLE 特征写入标准 CCCD 订阅描述符；仅对用户选择的特征执行。仅在车辆静止时操作。\n提示：Android 12+ 需要附近设备权限；Android 11 及更早版本扫描可能需要定位权限及开启系统定位。 ");
        disclaimer.setTextSize(11); disclaimer.setTextColor(0xFF6B7280);
        LinearLayout.LayoutParams disLp = new LinearLayout.LayoutParams(-1, -2); disLp.topMargin = dp(5); root.addView(disclaimer, disLp);
        setContentView(root);
    }

    private TextView sectionTitle(String text) {
        TextView tv = new TextView(this); tv.setText(text); tv.setTextSize(14); tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD); tv.setTextColor(0xFF172033);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(8); lp.bottomMargin = dp(3); tv.setLayoutParams(lp); return tv;
    }
    private void addButton(LinearLayout parent, String label, View.OnClickListener click, float weight) {
        Button b = new Button(this); b.setText(label); b.setTextSize(11); b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), weight); lp.setMargins(dp(2), dp(2), dp(2), dp(2)); parent.addView(b, lp);
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void requestPermissionsIfNeeded() {
        List<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), REQ_PERMS);
        else setStatus("权限已就绪，可以开始扫描。", false);
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) {
            boolean ok = true; for (int r : grantResults) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            setStatus(ok ? "权限已授予，可以开始扫描。" : "权限未完整授予，请在系统设置中允许附近设备/定位权限。", !ok);
        }
    }
    private boolean hasBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private void startScan() {
        if (adapter == null) { setStatus("设备不支持蓝牙。", true); return; }
        if (!hasBlePermissions()) { requestPermissionsIfNeeded(); return; }
        if (!adapter.isEnabled()) { setStatus("请先在系统设置中打开蓝牙。", true); return; }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { setStatus("无法获取 BLE 扫描器。", true); return; }
        devices.clear(); deviceRows.clear(); deviceAdapter.notifyDataSetChanged(); selectedDeviceIndex = -1;
        try {
            scanner.startScan(scanCallback); scanning = true; setStatus("正在扫描，约 12 秒后自动停止…", false); appendLog("开始 BLE 扫描");
            handler.postDelayed(() -> { if (scanning) stopScan(); }, 12000);
        } catch (SecurityException e) { setStatus("缺少蓝牙权限：" + e.getMessage(), true); }
    }
    private void stopScan() {
        if (scanner != null && scanning && hasBlePermissions()) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
        }
        if (scanning) appendLog("停止 BLE 扫描"); scanning = false; setStatus("扫描结束，共发现 " + devices.size() + " 个设备。", false);
    }
    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) { runOnUiThread(() -> addScanResult(result)); }
        @Override public void onBatchScanResults(List<ScanResult> results) { runOnUiThread(() -> { for (ScanResult r : results) addScanResult(r); }); }
        @Override public void onScanFailed(int errorCode) { runOnUiThread(() -> { scanning = false; setStatus("扫描失败，错误码 " + errorCode, true); appendLog("扫描失败 error=" + errorCode); }); }
    };
    private void addScanResult(ScanResult result) {
        BluetoothDevice d = result.getDevice(); String addr;
        try { addr = d.getAddress(); } catch (SecurityException e) { addr = "地址不可读"; }
        if (addr == null) addr = "未知地址";
        devices.put(addr, result);
        String name = safeName(d); if (name.isEmpty()) name = "（无名称设备）";
        String row = addr + "\n" + name + "   RSSI " + result.getRssi() + " dBm";
        int existing = -1; for (int i=0;i<deviceRows.size();i++) if (deviceRows.get(i).startsWith(addr + "\n")) { existing=i; break; }
        if (existing >= 0) deviceRows.set(existing, row); else deviceRows.add(row);
        deviceAdapter.notifyDataSetChanged();
    }
    private String safeName(BluetoothDevice d) { try { String n = d.getName(); return n == null ? "" : n; } catch (SecurityException e) { return ""; } }

    private void connectSelected() {
        if (!hasBlePermissions()) { requestPermissionsIfNeeded(); return; }
        if (connectedDevice == null) { toast("请先在上方点选一个设备"); return; }
        stopScan();
        if (gatt != null) { try { gatt.close(); } catch (Exception ignored) {} gatt = null; }
        try {
            setStatus("正在连接 " + safeName(connectedDevice) + "…", false);
            if (Build.VERSION.SDK_INT >= 23) gatt = connectedDevice.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            else gatt = connectedDevice.connectGatt(this, false, gattCallback);
            appendLog("发起 GATT 连接：" + safeName(connectedDevice));
        } catch (SecurityException e) { setStatus("连接失败：缺少权限。", true); }
    }
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int statusCode, int newState) {
            runOnUiThread(() -> {
                appendLog("连接状态 status=" + statusCode + " state=" + (newState == BluetoothProfile.STATE_CONNECTED ? "CONNECTED" : newState == BluetoothProfile.STATE_DISCONNECTED ? "DISCONNECTED" : newState));
                if (statusCode == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                    setStatus("已连接，正在发现 GATT 服务…", false);
                    try { g.discoverServices(); } catch (SecurityException e) { setStatus("发现服务失败：权限不足", true); }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) { setStatus("设备已断开。", true); characteristics.clear(); characteristicRows.clear(); characteristicAdapter.notifyDataSetChanged(); }
                else if (statusCode != BluetoothGatt.GATT_SUCCESS) setStatus("连接异常，状态码 " + statusCode, true);
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int statusCode) {
            runOnUiThread(() -> {
                characteristics.clear(); characteristicRows.clear();
                if (statusCode != BluetoothGatt.GATT_SUCCESS) { setStatus("服务发现失败，状态码 " + statusCode, true); return; }
                List<BluetoothGattService> services = g.getServices();
                appendLog("发现服务数量：" + services.size());
                for (BluetoothGattService s : services) {
                    appendLog("SERVICE " + s.getUuid() + " type=" + s.getType());
                    for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                        characteristics.add(c);
                        String props = propertyNames(c.getProperties());
                        String row = "服务 " + shortUuid(s.getUuid()) + "\n特征 " + c.getUuid() + "\n权限 " + props;
                        characteristicRows.add(row);
                        appendLog("  CHAR " + c.getUuid() + " properties=" + props);
                    }
                }
                characteristicAdapter.notifyDataSetChanged(); selectedCharacteristicIndex = -1;
                setStatus("服务发现完成：" + services.size() + " 个服务，" + characteristics.size() + " 个特征。", false);
            });
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int statusCode) {
            byte[] value = c.getValue();
            runOnUiThread(() -> { appendLog("READ " + c.getUuid() + " status=" + statusCode + " value=" + hex(value)); setStatus(statusCode == BluetoothGatt.GATT_SUCCESS ? "读取完成。" : "读取失败，状态码 " + statusCode, statusCode != BluetoothGatt.GATT_SUCCESS); });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            byte[] copy = value == null ? new byte[0] : value.clone();
            runOnUiThread(() -> appendLog("NOTIFY " + c.getUuid() + " value=" + hex(copy)));
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] value = c.getValue();
            runOnUiThread(() -> appendLog("NOTIFY " + c.getUuid() + " value=" + hex(value)));
        }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int statusCode) {
            runOnUiThread(() -> appendLog("订阅描述符写入 status=" + statusCode + " uuid=" + descriptor.getUuid()));
        }
    };

    private String propertyNames(int p) {
        List<String> a = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) a.add("Read");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) a.add("Write");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) a.add("WriteNoResponse");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) a.add("Notify");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) a.add("Indicate");
        if ((p & BluetoothGattCharacteristic.PROPERTY_SIGNED_WRITE) != 0) a.add("SignedWrite");
        return a.isEmpty() ? "无常见权限标记" : android.text.TextUtils.join(", ", a);
    }
    private String shortUuid(UUID uuid) { return uuid.toString(); }
    private void showSelectedCharacteristic() {
        if (selectedCharacteristicIndex < 0 || selectedCharacteristicIndex >= characteristics.size()) return;
        BluetoothGattCharacteristic c = characteristics.get(selectedCharacteristicIndex);
        selectedInfo.setText("选中：" + c.getUuid() + "\n属性：" + propertyNames(c.getProperties()));
    }
    private BluetoothGattCharacteristic selectedCharacteristic() {
        if (selectedCharacteristicIndex < 0 || selectedCharacteristicIndex >= characteristics.size()) { toast("请先选择一个特征"); return null; }
        if (gatt == null) { toast("尚未连接设备"); return null; }
        return characteristics.get(selectedCharacteristicIndex);
    }
    private void readSelected() {
        BluetoothGattCharacteristic c = selectedCharacteristic(); if (c == null) return;
        if ((c.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) == 0) { toast("该特征未声明 Read 权限"); return; }
        if (!hasBlePermissions()) { requestPermissionsIfNeeded(); return; }
        try {
            boolean started = gatt.readCharacteristic(c);
            appendLog("请求读取 " + c.getUuid() + " accepted=" + started);
            if (!started) toast("系统未接受读取请求；可能正在进行其他 GATT 操作");
        } catch (SecurityException e) { toast("读取失败：权限不足"); }
    }
    private void enableNotify() {
        BluetoothGattCharacteristic c = selectedCharacteristic(); if (c == null) return;
        int props = c.getProperties(); boolean notify = (props & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0; boolean indicate = (props & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0;
        if (!notify && !indicate) { toast("该特征未声明 Notify/Indicate"); return; }
        if (!hasBlePermissions()) { requestPermissionsIfNeeded(); return; }
        BluetoothGattDescriptor cccd = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
        if (cccd == null) { toast("未找到标准 CCCD 描述符，无法订阅"); return; }
        try {
            if (!gatt.setCharacteristicNotification(c, true)) { toast("系统未能启用本地通知"); return; }
            byte[] value = notify ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.ENABLE_INDICATION_VALUE;
            boolean queued;
            if (Build.VERSION.SDK_INT >= 33) queued = gatt.writeDescriptor(cccd, value) == BluetoothStatusCodes.SUCCESS;
            else { cccd.setValue(value); queued = gatt.writeDescriptor(cccd); }
            appendLog("订阅 " + c.getUuid() + " requestAccepted=" + queued);
            toast(queued ? "已请求订阅；请观察日志中的 NOTIFY" : "系统未接受订阅请求");
        } catch (SecurityException e) { toast("订阅失败：权限不足"); }
    }
    private void disconnect() {
        if (gatt != null) {
            try { if (hasBlePermissions()) gatt.disconnect(); gatt.close(); } catch (Exception ignored) {}
            gatt = null; characteristics.clear(); characteristicRows.clear(); characteristicAdapter.notifyDataSetChanged();
            appendLog("已请求断开并释放 GATT 连接"); setStatus("已断开连接。", false);
        } else setStatus("当前没有连接。", false);
    }
    private void exportLog() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "ninebot_ble_diagnostic_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt");
        try { startActivityForResult(intent, CREATE_EXPORT); } catch (Exception e) { toast("无法打开系统文件保存器"); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                String report = "九号 BLE 检测与诊断报告\n时间：" + new Date() + "\n设备：" + (connectedDevice == null ? "未连接" : safeName(connectedDevice)) + "\n\n" + log;
                if (out != null) { out.write(report.getBytes(StandardCharsets.UTF_8)); out.flush(); toast("日志已导出"); }
            } catch (Exception e) { toast("导出失败：" + e.getMessage()); }
        }
    }
    private String hex(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return "<空>";
        StringBuilder b = new StringBuilder(); for (byte value : bytes) b.append(String.format(Locale.US, "%02X ", value & 0xFF)); return b.toString().trim();
    }
    private void appendLog(String message) {
        String line = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date()) + "  " + message;
        log.append(line).append('\n');
        android.util.Log.i("NinebotBleDoctor", line);
    }
    private void setStatus(String text, boolean error) { if (status != null) { status.setText(text); status.setTextColor(error ? 0xFFB42318 : 0xFF2457C5); } }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    @Override protected void onDestroy() { stopScan(); if (gatt != null) { try { gatt.close(); } catch (Exception ignored) {} gatt = null; } super.onDestroy(); }
}
